//
//  PostCell.swift
//  Parstagram
//
//  Created by geek on 12/23/19.
//  Copyright © 2019 annievan2000. All rights reserved.
//

import UIKit
import AlamofireImage

class PostCell: UITableViewCell {


    @IBOutlet weak var photoView: UIImageView!
    
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var captionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
