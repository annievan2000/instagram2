//
//  FeedViewController.swift
//  Parstagram
//
//  Created by geek on 12/22/19.
//  Copyright © 2019 annievan2000. All rights reserved.
//

import UIKit
import Parse
import AlamofireImage
import Alamofire
import MessageInputBar // Step 1

class FeedViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, MessageInputBarDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    // Create an instance of it step 2
    let commentBar = MessageInputBar()
    
    // var changes
    var showsCommentBar = false
    var posts = [PFObject]()
    var selectedPost: PFObject! // an optional
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        commentBar.inputTextView.placeholder = "Add a comment.."
        commentBar.sendButton.title = "Post"
        commentBar.delegate = self // Anytime that you have something that fires events, fires event when pressed send
        
        tableView.delegate = self
        tableView.dataSource = self
        
        // pull screen pulls keyboard down
        tableView.keyboardDismissMode = .interactive
        
        let center = NotificationCenter.default
        
        // Observe this event
        center.addObserver(self, selector: #selector(keyboardWillBeHidden(note:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        DataRequest.addAcceptableImageContentTypes(["application/octet-stream"])
        // Do any additional setup after loading the view.
    }
    
    // Will be called when keyboard is hiding
    @objc func keyboardWillBeHidden(note: Notification) {
        commentBar.inputTextView.text = nil// Useful to clear text filed
        showsCommentBar = false
        becomeFirstResponder()
    }
    
    // Step 3
    override var inputAccessoryView: UIView? {
        return commentBar
    }
    
    // Step 4
    override var canBecomeFirstResponder: Bool {
        return showsCommentBar
    }
    
    // fires after pressing send
    func messageInputBar(_ inputBar: MessageInputBar, didPressSendButtonWith text: String) {
    
        //Create the comment
        let comment = PFObject(className: "Comments")
        comment["text"] = text
        comment["post"] = selectedPost
        comment["user"] = PFUser.current()!
        
        // Add new category comments to post tab
        selectedPost.add(comment, forKey: "comments")
        
        selectedPost.saveInBackground { (success, error) in
            if success {
                print("comment saved")
            }
            else {
                print("error printing comment")
            }
        }
        
        tableView.reloadData() // Reload data is imoprtant bc it immediately adds the comment
        
        // Clear out
        commentBar.inputTextView.text = nil// Useful to clear text filed
        
        showsCommentBar = false
        becomeFirstResponder()
        commentBar.inputTextView.resignFirstResponder()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let query = PFQuery(className: "Posts")
        // include key gives the actual object, dereferences
        // need to get references
        query.includeKeys(["author", "comments", "comments.user"])
        query.limit = 20
        
        query.findObjectsInBackground { (posts, error) in
            if posts != nil {
                self.posts = posts!
                self.tableView.reloadData()
            }
            
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // number of comments plus one
        let post = posts[section]
        let comments = (post["comments"] as? [PFObject]) ?? []
        // comments are optional bc they could be there or nil () ?? [] if left is nil set equal to []
        return comments.count + 2
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // as many sections as there are posts
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let post = posts[indexPath.section]
        let comments = (post["comments"] as? [PFObject]) ?? []

        if indexPath.row == 0 {
            // grab the post
            let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell") as! PostCell
            
            let user = post["author"] as! PFUser
            
            cell.usernameLabel.text = user.username
            //print("this is username ", user.username)
            
            cell.captionLabel.text = post["caption"] as! String
            //print("this is username ", post["caption"] as? String)
            
            let imageFile = post["image"] as! PFFileObject
            let urlString = imageFile.url!
            let url = URL(string: urlString)!
            
            //cell.photoView.af_setImage(withURL: url)
            cell.photoView.af_setImage(withURL: url)
            
            return cell
        }
        else if indexPath.row <= comments.count {
            let cell = tableView.dequeueReusableCell(withIdentifier: "Comment1Cell") as! Comment1Cell
            
            // 0th one is the post, 0th comment on second row
            let comment = comments[indexPath.row - 1 ]
            
            // Always cast when its coming out of a dictionary
            cell.commentLabel.text = comment["text"] as? String
            
            let user = comment["user"] as! PFUser
            cell.nameLabel.text = user.username
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "AddCommentCell")!
            return cell
        }
        
    }

    // everytime user taps, this function executes
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let post = posts[indexPath.section]
        // Need to remember this post
        selectedPost = post
    
        let comments = (post["comments"] as? [PFObject]) ?? []
        
        let commentsCount = comments.count
        let indexPathRow = indexPath.row
        
        // if you are that last cell then show the comments bar
        if indexPathRow == commentsCount + 1 {
            showsCommentBar = true
            becomeFirstResponder()
            // raise the keyboard
            commentBar.inputTextView.becomeFirstResponder()
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func onLogoutButton(_ sender: Any) {
        PFUser.logOut()
        let main = UIStoryboard(name: "Main", bundle: nil)
        let loginViewController = main.instantiateViewController(withIdentifier: "LoginViewController")
        
        // SOURCE: https://stackoverflow.com/questions/56588843/uiapplication-shared-delegate-equivalent-for-scenedelegate-xcode11
        // Remember to cast it
        let delegate = self.view.window?.windowScene?.delegate as! SceneDelegate
        
        delegate.window?.rootViewController = loginViewController
        
        
    }
    
}

